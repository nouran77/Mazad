<!doctype html>
<html class="no-js" lang="en" dir="ltr">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="x-ua-compatible" content="ie=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>
        <?php echo $__env->yieldContent('title','Mazad Online'); ?>
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/foundation.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/app.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link href="http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css" rel="stylesheet">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>


</head>
<body>
<div class="topnav">
    <div class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <!-- Logo -->
                    <div class="logo">
                        <img src="images/logo.png" style="height: 70px; width: 70px;"/>

                    </div>
                </div>

                <div class="col-md-3 pull-right">
                    <div class="navbar navbar-inverse" role="banner" id="edit">
                        <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation" >
                            <ul class="nav navbar-nav">
                                    <!-- Authentication Links -->
                                    <?php if(Auth::guest()): ?>
                                        <a href="<?php echo e(route('login')); ?>">Login</a>
                                        <a href="<?php echo e(route('register')); ?>">Register</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/admin')); ?>"><?php echo e(Auth::user()->name); ?></a>
                                        <a href="<?php echo e(url('/logout')); ?>">Logout</a>
                                    <?php endif; ?>
                                </ul>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div>
</div><div class="page-content">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info">
            <p><?php echo e(Session::get('message')); ?></p>
        </div>
    <?php endif; ?>

</div><!--/Page Content-->


<?php echo $__env->yieldContent('content'); ?>


<script src="<?php echo e(asset('dist/js/vendor/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/app.js')); ?>"></script>
</body>
</html>
