<?php $__env->startSection('title','item'); ?>
<?php $__env->startSection('content'); ?>
    <!-- products listing -->
    <!-- Latest SHirts -->
    <div class="row">
        <div class="small-5 small-offset-1 columns">
            <div class="item-wrapper">
                <div class="img-wrapper">
                    <a href="#">
                        <img src="http://localhost/my-site/MazadProject/storage/app/<?php echo e($item[0]->image); ?>"/>
                    </a>
                </div>
            </div>
        </div>
    <div class="small-6 columns">
        <div class="item-wrapper">
            <h3 class="subheader">
                <span class="price-tag">$<?php echo e($item[0]->price); ?></span> <?php echo e($item[0]->name); ?>

            </h3>
            <div class="row">
                <div class="large-12 columns">
                    <label>
                    <p>
                    Description: <?php echo e($item[0]->description); ?>

                    </p>
                    <p>
                    Owner: <?php echo e($item[0]->user); ?>

                    <br>
                    Location: <?php echo e($item[0]->location); ?>

                    </p>
                    </label>
                    <form method="post" action="bid">
                        <input type="text" name="bid" placeholder="Enter your bid here">
                        <input type="hidden" name="id" value="<?php echo e($item[0]->id); ?>">
                        <button type="submit" class="button expanded">Bid</button>
                    </form>
                </div>
            </div>
            <p class="text-left subheader">
        </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>