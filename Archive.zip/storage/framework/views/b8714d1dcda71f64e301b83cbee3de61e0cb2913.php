<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-4">
            <div class="item-wrapper">
                <div class="img-wrapper">
                    <a href="#">
                        <img src="http://localhost/my-site/MazadProject/storage/app/<?php echo e($item->image); ?>" style="width: 200px; height: 200px;"/>
                    </a>
                </div>
               <div class="col-sm-12 item-options">
                    <a style="margin: 20px;" class="glyphicon glyphicon glyphicon-trash btn btn-primary" href="admin/delete/<?php echo e($item->id); ?>"></a>
                <form method="post">
                    <?php echo e(csrf_field()); ?>

                    <a type="submit" href="admin/edit/<?php echo e($item->id); ?>" class="glyphicon glyphicon-edit btn btn-danger"></a>
                </form>
               </div>
                <h3 class="item-title">
                        <?php echo e($item->name); ?>

                </h3>
                <h4>
                   Price: $<?php echo e($item->price); ?>

                </h4>
                <h5>
                   Heighst Bid: $<?php echo e($item->bid); ?>

                </h5>
                <h5>
                   No of bid: <?php echo e($item->no_bid); ?>

                </h5>
                <h5>
                   Owner: <?php echo e($item->user); ?>

                </h5>
                <p>
                    <?php echo e($item->description); ?>

                </p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>