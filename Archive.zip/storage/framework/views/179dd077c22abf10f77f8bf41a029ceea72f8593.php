<!doctype html>
<html class="no-js" lang="en" dir="ltr">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="x-ua-compatible" content="ie=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>
        <?php echo $__env->yieldContent('title','Mickey Shirts'); ?>
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/foundation.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/app.css')); ?>"/>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css" rel="stylesheet">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>


</head>
<body>
<?php echo $__env->make('admin.layout.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info">
            <p><?php echo e(Session::get('message')); ?></p>
        </div>
    <?php endif; ?>

</div><!--/Page Content-->


<?php echo $__env->yieldContent('content'); ?>


<script src="<?php echo e(asset('dist/js/vendor/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/app.js')); ?>"></script>
</body>
</html>
