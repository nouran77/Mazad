
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

    <div class="col-sm-12 edit-header">
    	<h1>Edit <?php echo e($items->name); ?></h1>
    </div>
		<form method="post" action="" enctype="multipart/form-data">
			   <?php echo e(csrf_field()); ?>

		  <div class="form-group row" >
		    <label for="exampleInputEmail1" class="col-sm-3 text-right">Name</label>
		   <div class="col-sm-9">
		   	 <input type="Item Name" name="name" class="form-control" id="itemName" placeholder="Enter item name" value="<?php echo e($items->name); ?>">
		   </div>
		  </div>
		  <div class="form-group row">
		    <label for="exampleInputPassword1" class="col-sm-3 text-right">Price</label>
		    <div class="col-sm-9">
		    	<input type="text" name="price" class="form-control" id="itemPrice" placeholder="Item Price" value="<?php echo e($items->price); ?>">
		    </div>
		  </div>
		 
		  
		  <div class="form-group row">
		    <label for="exampleInputPassword1" class="col-sm-3 text-right">Description</label>
		    <div class="col-sm-9">
		    	 <textarea class="form-control" id="exampleTextarea" name="desc" rows="3"><?php echo e($items->description); ?></textarea>
		    </div>
		  </div>
		   <div class="form-group form-check">
		   <div class="col-sm-3"></div>
		    <label class="form-check-label col-sm-9">
		      <input type="checkbox" name="state" class="form-check-input" <?php echo e($on); ?>>
		      Online
		    </label>
		  </div>
		  <div class="form-group row">
		    <label for="exampleInputFile" class="col-sm-3 text-right">Image</label>
		   <div class="col-sm-7">
		   	 <input type="file" class="form-control" id="exampleInputFile" name="image" aria-describedby="fileHelp">
		     <small id="fileHelp" class="form-text text-muted">you can upload image for your item</small>
		   </div>
		   <div class="col-sm-2">
		   	<a href="#" class="edit-item-image">
                <img src="<?php echo e(url($items->image)); ?>"/>
            </a>
		   </div>
		   
		  </div>
		  <div class="form-group row"></div>
		  <label for="exampleInputFile" class="col-sm-3"></label>
		  <div class="col-sm-9">
		  	 <button type="submit" class="btn btn-primary edit-button">Save Changes</button>
		  </div>
		 
		</form>
	</div>
	<div>
		<ul>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>